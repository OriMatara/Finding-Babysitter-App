package com.example.finalproject;


import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.UUID;


public class MainActivity extends AppCompatActivity {

    public String shareFacebook;

      private FirebaseAuth mAuth;

    private ImageView profilePic;
    private FirebaseStorage storage;
    private StorageReference storageReference;
    private DatabaseReference root = FirebaseDatabase.getInstance().getReference("image");

    String UserName;
    String IdNumber;
    String PhoneNumber;
    String AddressPostal;
    String Age;
    String YearsOfExperience;
    String Salary;
    String gender;
    String proficiency;
    String FacebookLink;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mAuth = FirebaseAuth.getInstance();

        profilePic = findViewById(R.id.imageView);
        storage = FirebaseStorage.getInstance();
        storageReference = storage.getReference();

    }

    public void retrievePicture(){
        try{
            final File localFile = File.createTempFile("images/", "jpg");
            storageReference.getFile(localFile)
                    .addOnSuccessListener(new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(FileDownloadTask.TaskSnapshot taskSnapshot) {
                            Toast.makeText(MainActivity.this,"Picture Retrieved", Toast.LENGTH_SHORT).show();
                            Bitmap bitmap = BitmapFactory.decodeFile(localFile.getAbsolutePath());
                            ((ImageView)findViewById(R.id.imageViewCard)).setImageBitmap(bitmap);
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(MainActivity.this,"Error Occurred", Toast.LENGTH_SHORT).show();
                        }
                    });
        }catch (IOException e){
            e.printStackTrace();
        }
    }

    public void writeFunc() {

        EditText fullName=findViewById(R.id.nameText);
        EditText fullId=findViewById(R.id.idText);
        EditText phone=findViewById(R.id.Phone);
        EditText address=findViewById(R.id.postal);
        EditText age=findViewById(R.id.Age);
        EditText yearsOfExperience=findViewById(R.id.YearsOfExperience);
        EditText salary=findViewById(R.id.salary);

        UserName = fullName.getText().toString();
        IdNumber = fullId.getText().toString();
        PhoneNumber = phone.getText().toString();
        AddressPostal = address.getText().toString();
        Age = age.getText().toString();
        YearsOfExperience = yearsOfExperience.getText().toString();
        Salary=salary.getText().toString();

//        gender ;
//        proficiency;

        RadioGroup radioGroup1 = findViewById(R.id.radioGroup1);
        int checked1 = radioGroup1.getCheckedRadioButtonId();

        RadioGroup radioGroup2 = findViewById(R.id.radioGroup2);
        int checked2 = radioGroup2.getCheckedRadioButtonId();

        if(checked1 ==  2131231019){
            gender="male";
        }
        else if(checked1 == 2131230939)
        {
            gender="female";
        }
        else {
            gender="other";
        }

        if(checked2 == 2131230857){
            proficiency="children";
        }
        else if(checked2 == 2131230823)
        {
            proficiency="babies";
        }
        else {
            proficiency="both";
        }

//        Babysitter babysitter = new Babysitter(UserName, AddressPostal, Age, YearsOfExperience, gender, Salary, proficiency, PhoneNumber, IdNumber, null);
//
//        FirebaseDatabase database = FirebaseDatabase.getInstance("https://newerfragment-74335-default-rtdb.firebaseio.com/");
//        DatabaseReference myRef = database.getReference("babysitters").child(babysitter.getUserId());
//
//        myRef.setValue(babysitter);

    }

    private  String getFileExtension(Uri mUri){
        ContentResolver cr = getContentResolver();
        MimeTypeMap mime = MimeTypeMap.getSingleton();
        return mime.getExtensionFromMimeType(cr.getType(mUri));
    }

    public void uploadPicture(Uri imagePic, Uri imageId) {
        EditText facebook=findViewById(R.id.facebookLink);
        FacebookLink = facebook.getText().toString();

        final ProgressDialog pd = new ProgressDialog(this);
        pd.setTitle("Uploading Image...");
        pd.show();

        final String randomKey = UUID.randomUUID().toString();
        // Create a reference to 'images/
        StorageReference mountainsRef = storageReference.child("images/" + randomKey);
        StorageReference riversRef = storageReference.child("imagesId/" + randomKey);



        mountainsRef.putFile(imagePic).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        pd.dismiss();

                        mountainsRef.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                            @Override
                            public void onSuccess(Uri uri) {


                                Babysitter babysitter = new Babysitter(UserName, AddressPostal, Age, YearsOfExperience, gender, Salary, proficiency, PhoneNumber, IdNumber, uri.toString(), FacebookLink);

                                FirebaseDatabase database = FirebaseDatabase.getInstance("https://newerfragment-74335-default-rtdb.firebaseio.com/");
                                DatabaseReference myRef = database.getReference("babysitters").child(babysitter.getUserId());

                                myRef.setValue(babysitter);
                                //Snackbar.make(findViewById(androidx.appcompat.R.id.content), "Image Uploaded", Snackbar.LENGTH_LONG).show();
                                Toast.makeText(getApplicationContext(), "Image Uploaded", Toast.LENGTH_LONG).show();
                            }
                        });
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        pd.dismiss();
                        Toast.makeText(getApplicationContext(), "Failed To Upload", Toast.LENGTH_LONG).show();
                    }
                })
                .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onProgress(@NonNull UploadTask.TaskSnapshot snapshot) {
                        double progressPercent = (100.00 * snapshot.getBytesTransferred() / snapshot.getTotalByteCount());
                        pd.setMessage("Percentage: " + (int) progressPercent + "%");
                    }
                });

        riversRef.putFile(imageId).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        pd.dismiss();
                        Toast.makeText(getApplicationContext(), "Image Uploaded", Toast.LENGTH_LONG).show();
                        //Snackbar.make(findViewById(androidx.appcompat.R.id.content), "Image Uploaded", Snackbar.LENGTH_LONG).show();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        pd.dismiss();
                        Toast.makeText(getApplicationContext(), "Failed To Upload", Toast.LENGTH_LONG).show();
                    }
                })
                .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onProgress(@NonNull UploadTask.TaskSnapshot snapshot) {
                        double progressPercent = (100.00 * snapshot.getBytesTransferred() / snapshot.getTotalByteCount());
                        pd.setMessage("Percentage: " + (int) progressPercent + "%");
                    }
                });
    }

    public void loginFunc(View view) {

        String email = ((EditText)findViewById(R.id.email)).getText().toString();
        String password = ((EditText)findViewById(R.id.password)).getText().toString();

        mAuth.signInWithEmailAndPassword(email,password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            //if login succeful then flag 1 and then going to cat
                           Toast.makeText(MainActivity.this, "login Ok", Toast.LENGTH_LONG).show();
                           // Log.d("result","login ok");
                            Navigation.findNavController(view).navigate((R.id.action_frag_login_to_mainFragment));


                        } else {
                            Toast.makeText(MainActivity.this, "login Fail", Toast.LENGTH_LONG).show();
                           // Log.d("result","login fail");

                        }
                    }

                });
    }


    public void RegisterFunc() {
//      EditText EmailUser = findViewById(R.id.regEmail);
//      EditText Password = findViewById(R.id.regPassword);
        String email = ((EditText)findViewById(R.id.regEmail)).getText().toString();
        String password = ((EditText)findViewById(R.id.regPassword)).getText().toString();
        //EditText Name = findViewById(R.id.regName);
        //String UserName = Name.getText().toString();

        mAuth.createUserWithEmailAndPassword(email,password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            Log.d("result","reg ok");
                            //Toast.makeText(MainActivity.this, "Register Ok", Toast.LENGTH_LONG).show();
                        } else {
                            Log.d("result","reg fail");
                            Toast.makeText(MainActivity.this, "Register Fail", Toast.LENGTH_LONG).show();
                        }
                    }
                });

    }


}
