package com.example.finalproject;

import android.app.Activity;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link fragment_view_babysitter_list#newInstance} factory method to
 * create an instance of this fragment.
 */
public class fragment_view_babysitter_list extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private static RecyclerView recycleView;
    private LinearLayoutManager layoutManager;

    public ArrayList<Babysitter> dataSet2;//old
    public ArrayList<Babysitter> dataSetOrdered;//new
   // public ArrayList<Babysitter> dataSetTemp;


    private static customerAdapter adapter;

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    public static String parentLocation;
    double distanceFromParent;
    Location temp;
    Location parentAddress;//get distance by parent location
    private Location l1;

    public fragment_view_babysitter_list() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment fragment_view_babysitter_list.
     */
    // TODO: Rename and change types and number of parameters
    public static fragment_view_babysitter_list newInstance(String param1, String param2) {
        fragment_view_babysitter_list fragment = new fragment_view_babysitter_list();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

//    public static void showRecycleView(ArrayList<Babysitter> dataSet) {
//        adapter= new customerAdapter(dataSet);
//        recycleView.setAdapter(adapter);
//    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        dataSet2 = new ArrayList<>();
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view=inflater.inflate(R.layout.fragment_view_babysitter_list, container, false);

        Bundle bundle = this.getArguments();

        if (bundle != null) {
            parentLocation = bundle.getString("key");
        }

        //TextView parentAddress11 = (TextView) view.findViewById(R.id.textViewAddressTest);
       // parentAddress11.setText(parentLocation);

        recycleView=(RecyclerView)view.findViewById(R.id.my_recycler_view);

        layoutManager=new LinearLayoutManager(getContext());

        recycleView.setLayoutManager(layoutManager);

        recycleView.setItemAnimator(new DefaultItemAnimator());


        readBabysitter(parentLocation);



        adapter= new customerAdapter(getParentFragment().getContext() ,dataSet2);

        recycleView.setAdapter(adapter);

        return view;
    }

    private double deg2rad(double deg) {
        return (deg * Math.PI / 180.0);
    }

    private double rad2deg(double rad) {
        return (rad * 180.0 / Math.PI);
    }

    private double distance(double lat1, double lon1, double lat2, double lon2) {
        double theta = lon1 - lon2;
        double dist = Math.sin(deg2rad(lat1)) * Math.sin(deg2rad(lat2)) + Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * Math.cos(deg2rad(theta));
        dist = Math.acos(dist);
        dist = rad2deg(dist);
        dist = dist * 60 * 1.1515;
        dist = dist * 1.609344;

        dist = (int)(Math.round(dist * 1000))/1000.0;

        return (dist);
    }


    public Location getCoordinates(String address) {
        Geocoder geocoder = new Geocoder(getContext());
        double doubleLat;
        double doubleLong;
        List<Address> addressList;
        try {
            addressList = geocoder.getFromLocationName(address, 1);
            if (addressList != null) {
                doubleLat = addressList.get(0).getLatitude();
                doubleLong = addressList.get(0).getLongitude();
                l1 = new Location(String.valueOf(doubleLat), String.valueOf(doubleLong));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return l1;
    }

    public void readBabysitter(String parentLocation){
        FirebaseDatabase database = FirebaseDatabase.getInstance("https://newerfragment-74335-default-rtdb.firebaseio.com/");
        DatabaseReference myRef = database.getReference("babysitters");

        parentAddress = getCoordinates(parentLocation);//parnet address from string

        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot snap: snapshot.getChildren()){
                    MainActivity mainActivity=(MainActivity) getActivity();
                    mainActivity.findViewById(R.id.loading_Babysitters).setVisibility(View.GONE);

                    Babysitter babysitter = snap.getValue(Babysitter.class);

                    Babysitter newBabysitter = new Babysitter(babysitter.getUserName(), babysitter.getAddress(), babysitter.getAge(), babysitter.getYearsOfExperience(), babysitter.getGender(), babysitter.getSalaryPerHour(), babysitter.getProficiency(), babysitter.getPhoneNumber(), babysitter.getUserId(), babysitter.getImageUrl(), babysitter.getFacebookLink(),0);
                    temp = getCoordinates(babysitter.getAddress());//get cordinats of babaysitter by string address
                    distanceFromParent = distance(Double.parseDouble(parentAddress.get_Latitude()), Double.parseDouble(parentAddress.get_Longitude()), Double.parseDouble(temp.get_Latitude()), Double.parseDouble(temp.get_Longitude()));
                    newBabysitter.setDistance(distanceFromParent);
                    dataSet2.add(newBabysitter);

                }
                Collections.sort(dataSet2, new DistanceComparator());
                adapter.notifyDataSetChanged();
            }


            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }

    class DistanceComparator implements Comparator<Babysitter> {
        @Override
        public int compare(Babysitter b1, Babysitter b2) {
            if (b1.getDistance() == b2.getDistance())
                return 0;
            else if (b1.getDistance() > b2.getDistance())
                return 1;
            else
                return -1;
        }
    }

}