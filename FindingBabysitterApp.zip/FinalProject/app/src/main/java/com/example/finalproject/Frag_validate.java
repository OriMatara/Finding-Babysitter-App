package com.example.finalproject;

import static android.app.Activity.RESULT_OK;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link Frag_validate#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Frag_validate extends Fragment {


    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    //the flag is selecting the correct image view to put the picture in it
    private int flag = 0;
    private Uri selectedImagePic;
    private Uri selectedImageId;

    TextView linkTextView;

    public Frag_validate() {
        // Required empty public constructor

    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment FragmentThree.
     */
    // TODO: Rename and change types and number of parameters
    public static Frag_validate newInstance(String param1, String param2) {
        Frag_validate fragment = new Frag_validate();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.frag_validate, container, false);
      //  TextView linkFacebook = view.findViewById(R.id.link);
      //  linkFacebook.setMovementMethod(LinkMovementMethod.getInstance());
        //add facebook link of babysitter
        //add picture

        ImageView image = view.findViewById(R.id.imageView);
        ImageView imageId = view.findViewById(R.id.imageViewId);
        Button selectImage=view.findViewById(R.id.selectImage);
        Button selectImageId=view.findViewById(R.id.identity);

        Button validate =view.findViewById(R.id.validateButton);


        validate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MainActivity mainActivity=(MainActivity) getActivity();
                mainActivity.uploadPicture(selectedImagePic,selectedImageId);
                Navigation.findNavController(getView()).navigate((R.id.action_fragmentThree_to_congratulations));
            }
        });

        selectImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                flag = 0;
                Intent intent=new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent,3);

            }
        });

        selectImageId.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flag = 1;
                Intent intent=new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent,3);
            }
        });

        return view;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode,Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(resultCode == RESULT_OK && data!=null && flag == 0){
            Uri selectedImage=data.getData();
            ImageView imageView= getView().findViewById(R.id.imageView);//maybe problem
            imageView.getLayoutParams().height = 400;//set image selected size
            imageView.setImageURI(selectedImage);
            selectedImagePic = selectedImage;
        }
        if(resultCode == RESULT_OK && data!=null && flag == 1){
            Uri selectedImage=data.getData();
            ImageView imageViewId= getView().findViewById(R.id.imageViewId);//maybe problem
            imageViewId.getLayoutParams().height = 400;//set image selected size
            imageViewId.setImageURI(selectedImage);
            selectedImageId = selectedImage;
        }
    }


}
