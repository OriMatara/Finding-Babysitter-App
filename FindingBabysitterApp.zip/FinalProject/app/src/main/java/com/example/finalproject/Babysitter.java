package com.example.finalproject;

import java.net.MalformedURLException;
import java.net.URL;

public class Babysitter {
    private String userName;
    private String address;
    private String age;
    private String yearsOfExperience;
    private String gender;
    private String salaryPerHour;
    private String proficiency;
    private String phoneNumber;
    private String userId;
//    private int id_;
    private String imageUrl;

    private double distance;

    private String facebookLink;

    private URL facebookUrl;

    public Babysitter(String userName, String address, String age, String yearsOfExperience, String gender, String salaryPerHour, String proficiency, String phoneNumber, String userId, String imageUrl, String facebookLink) {
        this.userName = userName;
        this.address = address;
        this.age = age;
        this.yearsOfExperience = yearsOfExperience;
        this.gender = gender;
        this.salaryPerHour = salaryPerHour;
        this.proficiency = proficiency;
        this.phoneNumber = phoneNumber;
        this.userId = userId;
        this.imageUrl = imageUrl;
        this.facebookLink = facebookLink;
    }

    public Babysitter(String userName, String address, String age, String yearsOfExperience, String gender, String salaryPerHour, String proficiency, String phoneNumber, String userId, String imageUrl, String facebookLink, double distance) {
        this.userName = userName;
        this.address = address;
        this.age = age;
        this.yearsOfExperience = yearsOfExperience;
        this.gender = gender;
        this.salaryPerHour = salaryPerHour;
        this.proficiency = proficiency;
        this.phoneNumber = phoneNumber;
        this.userId = userId;
        this.imageUrl = imageUrl;
        this.facebookLink = facebookLink;
        this.distance = distance;
    }


    public Babysitter() {
    }

    @Override
    public String toString() {
        return "Babysitter{" +
                "userName='" + userName + '\'' +
                ", address='" + address + '\'' +
                ", age='" + age + '\'' +
                ", yearsOfExperience='" + yearsOfExperience + '\'' +
                ", gender='" + gender + '\'' +
                ", salaryPerHour='" + salaryPerHour + '\'' +
                ", proficiency='" + proficiency + '\'' +
                ", phoneNumber='" + phoneNumber + '\'' +
                ", userId='" + userId + '\'' +
                '}';
    }

    public double getDistance() {
        return distance;
    }

    public void setDistance(double distance) {
        this.distance = distance;
    }

    public String getFacebookLink() {
        try {
            facebookUrl = new URL(facebookLink);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        return facebookLink;
    }

    public void setFacebookLink(String facebookLink) {
        this.facebookLink = facebookLink;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getYearsOfExperience() {
        return yearsOfExperience;
    }

    public void setYearsOfExperience(String yearsOfExperience) {
        this.yearsOfExperience = yearsOfExperience;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getSalaryPerHour() {
        return salaryPerHour;
    }

    public void setSalaryPerHour(String salaryPerHour) {
        this.salaryPerHour = salaryPerHour;
    }

    public String getProficiency() {
        return proficiency;
    }

    public void setProficiency(String proficiency) {
        this.proficiency = proficiency;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

//    public int getImage() {
//        return image;
//    }
//
//    public void setImage(int image) {
//        this.image = image;
//    }
//
//    public int getId_() {
//        return id_;
//    }
//
//    public void setId_(int id_) {
//        this.id_ = id_;
//    }



}
