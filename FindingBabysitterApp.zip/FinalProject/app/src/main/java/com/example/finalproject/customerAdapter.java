package com.example.finalproject;

import android.annotation.SuppressLint;
import android.content.Context;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class customerAdapter extends RecyclerView.Adapter<customerAdapter.MyViewHolder>{
    private ArrayList<Babysitter> dataSet;
    private Context context;

    URL FacebookLink;

    public customerAdapter(Context context,ArrayList<Babysitter> dataSet){
        this.context = context;
        this.dataSet=dataSet;
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{
        CardView cardView;
        TextView textViewName;
        TextView textViewCity;
        TextView textViewAge;
        TextView textViewYearsExperience;
        TextView textViewGender;
        TextView textViewProficiency;
        TextView textViewSalary;
        TextView textViewPhone;
        TextView textViewId;
        ImageView imageViewIcon;

        TextView textViewLocation;

        TextView textViewFacebook;

        public MyViewHolder(View itemView){
            super(itemView);
            cardView=(CardView) itemView.findViewById(R.id.card_view);
            textViewName=(TextView) itemView.findViewById(R.id.textViewName);
            textViewCity=(TextView) itemView.findViewById(R.id.textViewCity);
            textViewAge=(TextView) itemView.findViewById(R.id.textViewAge);
            textViewYearsExperience=(TextView) itemView.findViewById(R.id.textViewYearsExperience);
            textViewGender = (TextView) itemView.findViewById(R.id.textViewGender);
            textViewProficiency=(TextView) itemView.findViewById(R.id.textViewProfeciency);
            textViewSalary=(TextView) itemView.findViewById(R.id.textViewSalary);
            textViewPhone=(TextView) itemView.findViewById(R.id.textViewPhone);
            textViewId = (TextView) itemView.findViewById(R.id.textViewId);
            imageViewIcon=(ImageView) itemView.findViewById(R.id.imageViewCard);
            textViewFacebook = (TextView) itemView.findViewById(R.id.textViewFacebookLink);

            textViewLocation=(TextView)itemView.findViewById(R.id.textViewTestLocation);
        }
    }
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View view= LayoutInflater.from(context).inflate(R.layout.cards_layout,parent,false);

        MyViewHolder myViewHolder=new MyViewHolder(view);
        return myViewHolder;

    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull MyViewHolder viewHolder, final int listposition) {
        Glide.with(context).load(dataSet.get(listposition).getImageUrl()).into(viewHolder.imageViewIcon);
        TextView textViewName=viewHolder.textViewName;
        TextView textViewCity=viewHolder.textViewCity;
        TextView textViewAge=viewHolder.textViewAge;
        TextView textViewYears=viewHolder.textViewYearsExperience;
        TextView textViewGender=viewHolder.textViewGender;
        TextView textViewProficiency=viewHolder.textViewProficiency;
        TextView textViewSalary=viewHolder.textViewSalary;
        TextView textViewPhone=viewHolder.textViewPhone;
        TextView textViewId = viewHolder.textViewId;
        ImageView imageViewIcon = viewHolder.imageViewIcon;
        TextView textViewLocation=viewHolder.textViewLocation;

        TextView textViewFacebook = viewHolder.textViewFacebook;
        CardView cardView=viewHolder.cardView;

        try {
            FacebookLink = new URL(dataSet.get(listposition).getFacebookLink());
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }

        textViewName.setText(" Name: "+dataSet.get(listposition).getUserName());
        textViewCity.setText(" City: "+dataSet.get(listposition).getAddress());
        textViewAge.setText(" Age: "+dataSet.get(listposition).getAge());
        textViewYears.setText(" Years of experience: "+dataSet.get(listposition).getYearsOfExperience());
        textViewGender.setText(" Gender: "+dataSet.get(listposition).getGender());
        textViewProficiency.setText(" Proficiency: "+dataSet.get(listposition).getProficiency());
        textViewSalary.setText(" Salary: "+dataSet.get(listposition).getSalaryPerHour());
        textViewPhone.setText(" Phone: "+dataSet.get(listposition).getPhoneNumber());
        textViewId.setText(" Id: "+dataSet.get(listposition).getUserId());
        textViewLocation.setText(" Distance: " + dataSet.get(listposition).getDistance() + " Km");

        textViewFacebook.setMovementMethod(LinkMovementMethod.getInstance());
        String text = "<a href='"+ dataSet.get(listposition).getFacebookLink()+"'>link</a>";
        textViewFacebook.setText(" Facebook: "+ Html.fromHtml(text));

        //textViewFacebook.setText(" Facebook: "+ dataSet.get(listposition).getFacebookLink());

//        imageView.setImageResource(dataSet.get(listposition).getImage());

//        Log.d("resultskuuaad:",dataSet.toString());

        cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               // Log.d("result","yes");
                //Toast.makeText(cardView.getContext(), "Pressed!", Toast.LENGTH_LONG).show();
                //expand details
            }
        });
    }

    @Override
    public int getItemCount() {
        return dataSet.size();
    }


}
